//
//  View.swift
//  Pensieve
//
//  Created by Stephen Dirk M. Weyns on 25/11/18.
//  Copyright © 2018 Pensieve. All rights reserved.
//

import UIKit

class MainView: UIView {
    var currentScrollView : UIScrollView? = nil
    
    var location = CGPoint(x: 0, y: 0)
    var offset = CGPoint(x: 0, y: 0)
    var xOffset = CGFloat(0)
    var yOffset = CGFloat(0)
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch : UITouch! =  touches.first! as UITouch
        print("that worked")
        location = touch.location(in: self)
        
        if currentScrollView == nil {
            if let touchedScrollView = self.hitTest(location, with: nil) as? UIScrollView {
                currentScrollView = touchedScrollView
                self.bringSubviewToFront(currentScrollView!)
                xOffset = (currentScrollView?.center.x)! - location.x
                yOffset = (currentScrollView?.center.y)! - location.y
                print("scrollview selected ")
            } else {
                //print("scrollview selected ")
                currentScrollView = nil
            }
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch : UITouch! =  touches.first! as UITouch
        
        location = touch.location(in: self)
        
        let newPoint = CGPoint(x: location.x + xOffset, y: location.y + yOffset)
        
        currentScrollView?.center = newPoint
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        currentScrollView = nil
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        currentScrollView = nil
    }

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
