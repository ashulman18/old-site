//
//  Singleton.swift
//  Pensieve
//
//  Created by Stephen Dirk M. Weyns on 6/12/18.
//  Copyright © 2018 Pensieve. All rights reserved.
//

import Foundation
import UIKit

class Singleton {
    static let sharedInstance = Singleton()
    
    var scrollView1 : ScrollView? = nil
    var recentlyDeleted = false
    
    //var numTags = 3
    
    var numMemories = 1
    
    var currentMemory = 0
    
    var images = [UIImage]()
    
    var tags1 = [String]()
    var tags2 = [String]()
    
    func numTags() -> Int {
        return 3 + tags1.count + tags2.count
    }
    
    private init() {
        //dont think i actually needed this
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        images.append(UIImage())
        
    }
}
