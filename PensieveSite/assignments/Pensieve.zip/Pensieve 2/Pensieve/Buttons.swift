//
//  Buttons.swift
//  Pensieve
//
//  Created by Stephen Dirk M. Weyns on 23/11/18.
//  Copyright © 2018 Pensieve. All rights reserved.
//

import UIKit

protocol ButtonsDelegate {
    func textButtonPressed(buttons: Buttons)
    func drawButtonPressed(buttons: Buttons)
    func cameraButtonPressed(buttons: Buttons)
    func microphoneButtonPressed(buttons: Buttons)
}

class Buttons: UIViewController {
    
    var delegate:ButtonsDelegate?
    var recording = false
    
    @IBAction func microphone(_ sender: UIButton) {
        self.delegate?.microphoneButtonPressed(buttons: self)
        if (sender.isSelected) {
            sender.isSelected = false
            sender.backgroundColor = nil
            recording = false
            //print("highlighted")
        } else if (!sender.isSelected) {
            sender.isSelected = true
            sender.backgroundColor = UIColor(red: 1, green: 1, blue: 0.85, alpha: 1)
            //print ("not highlighted")
            recording = true
        }
    }
    
    @IBAction func draw(_ sender: UIButton) {
        self.delegate?.drawButtonPressed(buttons: self)
        if (sender.isSelected) {
            sender.isSelected = false
            sender.backgroundColor = nil
            print("highlighted")
        } else if (!sender.isSelected) {
            sender.isSelected = true
            sender.backgroundColor = UIColor(red: 1, green: 1, blue: 0.85, alpha: 1)
            print ("not highlighted")
        }
    }
    
    @IBAction func text(_ sender: Any) {
        self.delegate?.textButtonPressed(buttons: self)
    }
    
    @IBAction func camera(_ sender: UIButton) {
        self.delegate?.cameraButtonPressed(buttons: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
