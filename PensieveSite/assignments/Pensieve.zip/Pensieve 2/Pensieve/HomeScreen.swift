//
//  HomeScreen.swift
//  Pensieve
//
//  Created by Stephen Dirk M. Weyns on 22/11/18.
//  Copyright © 2018 Pensieve. All rights reserved.
//

import UIKit
import AVFoundation

struct Constants {
    static let embedSegue = "embedSegue"
}

class HomeScreen: UIViewController, ButtonsDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate, UITextFieldDelegate, AVAudioRecorderDelegate {
    
    var lastPoint = CGPoint.zero
    var color = UIColor.black
    var brushWidth: CGFloat = 3.0
    var opacity: CGFloat = 1.0
    var swiped = false
    var drawing = false
    var held = false
    var heldImage: UIImageView? = nil
    var heldButton: UIButton? = nil
    var currTrash: UIButton? = nil
    var done = false

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == Constants.embedSegue {
            let buttons = segue.destination as! Buttons
            buttons.delegate = self
        }
    }
    
    @IBOutlet weak var instructions: UIImageView!
    
    @IBOutlet weak var mainImage: UIImageView!
    
    @IBOutlet weak var tempDrawImage:UIImageView!
    
//    @IBAction func unwindToVC2(segue:UIStoryboardSegue) {
//        print("unwound2")
//    }
    
//    @IBAction func unwindToVC1(segue:UIStoryboardSegue) {
//        print("unwound")
//    }
    
    
    @IBAction func tapped(_ sender: Any) {
        fadeOut(duration: 0.5)
        print(held)
        if let gesture = sender as? UITapGestureRecognizer {
            if scrollView.isUserInteractionEnabled {
                
                if (held == true) {
                    held = false
                    //get rid of the clicked image that you stored
                    self.view.subviews[3].isUserInteractionEnabled = true
                    heldButton = nil
                    heldImage = nil
                    currTrash?.removeFromSuperview()
                    currTrash = nil
                    //get rid of all those buttons
                } else {
                    let tapLocation = gesture.location(in: scrollView)
                    let myTextField: UITextField = UITextField(frame: CGRect(x: tapLocation.x - 150, y: tapLocation.y - 15, width: 300.00, height: 30.00))
                    myTextField.becomeFirstResponder()
                    myToolbar = UIToolbar(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
                    
                    // set the color of the toolbar
                    myToolbar.barStyle = .default
                    myToolbar.tintColor = UIColor.black
                    myToolbar.backgroundColor = UIColor.clear
                    
                    let flexButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
                    
                    let colImg = #imageLiteral(resourceName: "Collections2")
                    let tagImg = #imageLiteral(resourceName: "Tag")
                    let collectButton = UIBarButtonItem(image: colImg, style: .done, target: self, action: #selector(self.collectClicked))
                    let tagButton = UIBarButtonItem(image: tagImg, style: .plain, target: self, action: #selector(self.tagClicked))
                    
                    // add the buttons on the toolbar
                    myToolbar.items = [flexButton, tagButton, collectButton]
                    
                    // add the toolbar to the view.
                    myTextField.inputAccessoryView = myToolbar
                    
                    myTextField.keyboardAppearance = UIKeyboardAppearance.dark
                    
                    
                    myTextField.delegate = self
                    let transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
                    myTextField.transform = transform
                    myTextField.isUserInteractionEnabled = true
                    myTextField.tintColor = .black
                    myTextField.contentMode = .scaleToFill
                    let newCenter = CGPoint(x: tapLocation.x + myTextField.bounds.width / 20, y: tapLocation.y)
                    myTextField.center = newCenter
                    self.view.subviews[0].addSubview(myTextField)
                }
                //held = false
                
            }
        }
        
        print("tapped")
    }
    
    @IBAction func keyToolbar2(_ sender: Any) {
        tagSuggs = UIToolbar(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        
        // set the color of the toolbar
        tagSuggs.barStyle = .default
        tagSuggs.tintColor = UIColor.black
        tagSuggs.backgroundColor = UIColor.clear
        
        let flexButton = UIBarButtonItem(title: "Family", style: .plain, target: self, action: nil)
        let collectButton = UIBarButtonItem(title: "LA Trip", style: .plain, target: self, action: nil)
        let tagButton = UIBarButtonItem(title: "Vacation", style: .plain, target: self, action: nil)
        let space = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        
        // add the buttons on the toolbar
        tagSuggs.items = [flexButton, space, tagButton, space, collectButton]
        
        // add the toolbar to the view.
        addTextField.inputAccessoryView = tagSuggs
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            let imageView = UIImageView(image: image)
            let width = (imageView.image?.size.width)! / 300
            let height = (imageView.image?.size.height)! / 300
            let convertedPoint = self.view.convert(self.view.center, to: scrollView)
            imageView.frame = CGRect(x: convertedPoint.x - width / 2, y: convertedPoint.y - height / 2, width: width, height: height) //change this width and height
            imageView.contentMode = .scaleToFill
            imageView.isUserInteractionEnabled = true
            let holdGesture = UILongPressGestureRecognizer(target: self, action: #selector(holdAction(sender:)))
            holdGesture.minimumPressDuration = 1.0 // 1 second press
            holdGesture.allowableMovement = 4
            imageView.addGestureRecognizer(holdGesture)
            self.view.subviews[0].addSubview(imageView)
            self.view.subviews[0].bringSubviewToFront(imageView)
        } else {
            //error
        }
        
        self.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func cameraButtonPressed(buttons: Buttons) {
        if (self.instructions.alpha > 0) {
            fadeOut(duration: 0.5)
        }
        
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        
        let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action:UIAlertAction) in
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                imagePickerController.sourceType = .camera
                self.present(imagePickerController, animated: true, completion: nil)
            } else {
                print("Camera not available")
            }
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { (action:UIAlertAction) in
            imagePickerController.sourceType = .photoLibrary
            self.present(imagePickerController, animated: true, completion: nil)
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(actionSheet, animated: true, completion: nil)

        print("camera was pressed")
    }
    
    func drawButtonPressed(buttons: Buttons) {
        if (self.instructions.alpha > 0) {
            fadeOut(duration: 0.5)
        }
        //enter draw mode
        if scrollView.isUserInteractionEnabled {
            scrollView.isUserInteractionEnabled = false
            drawing = true
        }  else {
            if (title == "HomeScreen") {
                saveLabel.isHidden = false
                UIView.animate(withDuration: 3, animations: { () -> Void in
                    self.saveLabel.alpha = 0
                    print("fading out save")
                }, completion: {(finished: Bool) in
                    print("fading out save done")
                    self.saveLabel.isHidden = true
                    self.saveLabel.alpha = 1
                })
            } else if (title == "HomeScreen2") {
                saveLabel2.isHidden = false
                UIView.animate(withDuration: 3, animations: { () -> Void in
                    self.saveLabel2.alpha = 0
                    print("fading out save")
                }, completion: {(finished: Bool) in
                    print("fading out save done")
                    self.saveLabel2.isHidden = true
                    self.saveLabel2.alpha = 1
                })
            }
            drawing = false
            
            let imageView = UIImageView(image: mainImage.image)
            if (imageView.image != nil) {
                
            
            //imageView.isMultipleTouchEnabled = false
                let width = (imageView.image?.size.width)! / 10
                let height = (imageView.image?.size.height)! / 10
                let convertedPoint = self.view.convert(self.view.center, to: scrollView)
                imageView.frame = CGRect(x: convertedPoint.x - width / 2, y: convertedPoint.y - height / 2, width: width, height: height) //change this width and height
                imageView.contentMode = .scaleToFill
                imageView.isUserInteractionEnabled = true
    //            imageView.layer.borderColor = UIColor.brown.cgColor
    //            imageView.layer.borderWidth = 0.2// as you wish
                let holdGesture = UILongPressGestureRecognizer(target: self, action: #selector(holdAction(sender:)))
                holdGesture.minimumPressDuration = 1.0 // 1 second press
                holdGesture.allowableMovement = 4
                imageView.addGestureRecognizer(holdGesture)
                
                self.view.subviews[0].addSubview(imageView)
                self.view.subviews[0].bringSubviewToFront(imageView)
            }
            mainImage.image = nil
            scrollView.isUserInteractionEnabled = true
        }
        
        print("draw was pressed")
    }
    
    private var tagSuggs: UIToolbar!
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        print("done was pressed")
        if (textField.text != "" && textField == addTextField) {
            insertNewTag()
        }
        if (textField != addTextField) {
            if (title == "HomeScreen") {
                saveLabel.isHidden = false
                UIView.animate(withDuration: 3, animations: { () -> Void in
                    self.saveLabel.alpha = 0
                    print("fading out save")
                }, completion: {(finished: Bool) in
                    print("fading out save done")
                    self.saveLabel.isHidden = true
                    self.saveLabel.alpha = 1
                })
            } else if (title == "HomeScreen2") {
                saveLabel2.isHidden = false
                UIView.animate(withDuration: 3, animations: { () -> Void in
                    self.saveLabel2.alpha = 0
                    print("fading out save")
                }, completion: {(finished: Bool) in
                    print("fading out save done")
                    self.saveLabel2.isHidden = true
                    self.saveLabel2.alpha = 1
                })
            }
        }
       
        
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func swipeToCollc(_ sender: Any) {
        print("swiped?")
        performSegue(withIdentifier: "toCollect", sender: nil)
        //pass the videos data
    }
    
    func captureScreen() -> UIImage
    {
        
        //UIGraphicsBeginImageContext(view.frame.size)
        print(view.frame.size.width)
        print(view.frame.size.height)
        UIGraphicsBeginImageContextWithOptions(CGSize(width: view.frame.size.width, height: view.frame.size.width), false, 0)
        view.layer.render(in: UIGraphicsGetCurrentContext()!)
       
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        //UIImageWriteToSavedPhotosAlbum(image!, nil, nil, nil)
        return image!
    }
    
    @objc func collectClicked() {
        print("collect clicked")
        //if (!done) {
        if (Singleton.sharedInstance.currentMemory <= Singleton.sharedInstance.images.count - 1) {
            Singleton.sharedInstance.images[Singleton.sharedInstance.currentMemory] = captureScreen()
        } else {
            Singleton.sharedInstance.images.append(captureScreen())
        }
        if title == "HomeScreen2" {
            Singleton.sharedInstance.tags2 = videos
            print("set tags for second screen")
        } else if title == "HomeScreen" {
            Singleton.sharedInstance.tags1 = videos
            print("set tags for first screen")
        }
        
        //pass the videos data
            performSegue(withIdentifier: "toCollect", sender: nil)
        //print("made it to collection")
            //done = true
//        } else {
//            print("unwinding")
//            performSegue(withIdentifier: "unwindToCollections", sender: self)
//        }
//
        //not sure if both of these are happening
        
    }
    
    @IBAction func collectionsButtonClick2(_ sender: Any) {
        if (Singleton.sharedInstance.currentMemory <= Singleton.sharedInstance.images.count - 1) {
            Singleton.sharedInstance.images[Singleton.sharedInstance.currentMemory] = captureScreen()
        } else {
            Singleton.sharedInstance.images.append(captureScreen())
        }
        if title == "HomeScreen2" {
            Singleton.sharedInstance.tags2 = videos
            print("set tags for second screen")
        } else if title == "HomeScreen" {
            Singleton.sharedInstance.tags1 = videos
            print("set tags for first screen")
        }
        
        //pass the videos data
        performSegue(withIdentifier: "toCollect", sender: nil)
    }
    @IBAction func collectionsButtonClick(_ sender: Any) {
        if (Singleton.sharedInstance.currentMemory <= Singleton.sharedInstance.images.count - 1) {
            Singleton.sharedInstance.images[Singleton.sharedInstance.currentMemory] = captureScreen()
        } else {
            Singleton.sharedInstance.images.append(captureScreen())
        }
        if title == "HomeScreen2" {
            Singleton.sharedInstance.tags2 = videos
            print("set tags for second screen")
        } else if title == "HomeScreen" {
            Singleton.sharedInstance.tags1 = videos
            print("set tags for first screen")
        }
        
        //pass the videos data
        performSegue(withIdentifier: "toCollect", sender: nil)
    }
    @objc func tagClicked() {
        print("tag clicked")
        tagPage.isHidden = false
        scrollView.isUserInteractionEnabled = false
        if (title == "HomeScreen") {
            containerView.isUserInteractionEnabled = false
        } else if (title == "HomeScreen2") {
            containerView2.isUserInteractionEnabled = false
        }
        
        //performSegue(withIdentifier: "tagClick", sender: nil)
    }
    
    @IBOutlet weak var containerView: UIView!
    private var myToolbar: UIToolbar!
    
    func textButtonPressed(buttons: Buttons) {
        if (self.instructions.alpha > 0) {
            fadeOut(duration: 0.5)
        }
        
        // make uitoolbar instance
        
        
        let newPoint = CGPoint(x: self.view.center.x, y: self.view.center.y)
        //print(newPoint)
        let convertedPoint = self.view.convert(newPoint, to: scrollView)
        //print(convertedPoint)
        
        let myTextField: UITextField = UITextField(frame: CGRect(x: 0, y: 0, width: 300.00, height: 30.00))
        myTextField.becomeFirstResponder()
        myToolbar = UIToolbar(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        
        // set the color of the toolbar
        myToolbar.barStyle = .default
        myToolbar.tintColor = UIColor.black
        myToolbar.backgroundColor = UIColor.clear
        
        let flexButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        
        let colImg = #imageLiteral(resourceName: "Collections2")
        let tagImg = #imageLiteral(resourceName: "Tag")
        let collectButton = UIBarButtonItem(image: colImg, style: .done, target: self, action: #selector(self.collectClicked))
        let tagButton = UIBarButtonItem(image: tagImg, style: .plain, target: self, action: #selector(self.tagClicked))
        
        // add the buttons on the toolbar
        myToolbar.items = [flexButton, tagButton, collectButton]
        
        // add the toolbar to the view.
        myTextField.inputAccessoryView = myToolbar
        //myTextField.center = self.view.center
        myTextField.delegate = self;
        let transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        myTextField.transform = transform
        myTextField.isUserInteractionEnabled = true;
        myTextField.tintColor = .black
        //let newCenter = CGPoint(x: convertedPoint.x, y: convertedPoint.y)
        myTextField.center = convertedPoint
        myTextField.keyboardAppearance = .dark
        self.view.subviews[0].addSubview(myTextField)
        print("text was pressed")
    }
    
    var recordingSession: AVAudioSession!
    var audioRecorder:AVAudioRecorder!
    var audioPlayer: AVAudioPlayer!
    var numberOfRecords = 0
    
    
    var path = URL(string: "")
    var paths = [URL]()
    var num = 100
    
    func getDirectory() -> URL
    {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentDirectory = paths[0]
        return documentDirectory
    }
    
    func displayAlert(title:String, message:String)
    {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "dismiss", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func microphoneButtonPressed(buttons: Buttons) {
        if (self.instructions.alpha > 0) {
            fadeOut(duration: 0.5)
        }
        if !buttons.recording {
            if audioRecorder == nil
            {
                let filename = getDirectory().appendingPathComponent("\(numberOfRecords).m4a")
                //numberOfRecords += 1
                
                let settings = [AVFormatIDKey: Int(kAudioFormatMPEG4AAC), AVSampleRateKey: 12000, AVNumberOfChannelsKey: 1, AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue]
                
                do
                {
                    audioRecorder = try AVAudioRecorder (url: filename, settings: settings)
                    audioRecorder.delegate = self
                    audioRecorder.prepareToRecord()
                    audioRecorder.record()
                    print(numberOfRecords)
                    //donebutton.isHidden = false
                    
                }
                catch
                {
                    print ("failed")
                    displayAlert(title: "Oops!", message: "Recording failed")
                }
            }
        } else if buttons.recording {
            if audioRecorder != nil {
                if (title == "HomeScreen") {
                    saveLabel.isHidden = false
                    UIView.animate(withDuration: 3, animations: { () -> Void in
                        self.saveLabel.alpha = 0
                        print("fading out save")
                    }, completion: {(finished: Bool) in
                        print("fading out save done")
                        self.saveLabel.isHidden = true
                        self.saveLabel.alpha = 1
                    })
                } else if (title == "HomeScreen2") {
                    saveLabel2.isHidden = false
                    UIView.animate(withDuration: 3, animations: { () -> Void in
                        self.saveLabel2.alpha = 0
                        print("fading out save")
                    }, completion: {(finished: Bool) in
                        print("fading out save done")
                        self.saveLabel2.isHidden = true
                        self.saveLabel2.alpha = 1
                    })
                }
                
                //Stopping audio recording
                audioRecorder.stop()
                audioRecorder = nil
                UserDefaults.standard.set(numberOfRecords, forKey: "myNumber")
                let img = UIImage(named: "audioIcon.jpg")
                //donebutton.isHidden = true
                let convertedPoint = self.view.convert(self.view.center, to: scrollView)
                let button = UIButton(frame: CGRect(x: convertedPoint.x - img!.size.width / 100, y: convertedPoint.y - img!.size.width / 100, width: img!.size.width / 50, height: img!.size.height / 50))
//                let button = UIButton(frame: CGRect(x: img?.size.width, y: img?.size.height, width: img?.size.width, height: img?.size.height))
                //num += 80
                
                button.setImage(img, for: .normal)
                button.setTitleColor(.black, for: .normal)
                
                path = getDirectory().appendingPathComponent("\(numberOfRecords).m4a")
                paths.append(path!)
                
                print(numberOfRecords)
                
                button.tag = numberOfRecords
                button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
                let holdGesture = UILongPressGestureRecognizer(target: self, action: #selector(holdAction(sender:)))
                holdGesture.minimumPressDuration = 1.0 // 1 second press
                holdGesture.allowableMovement = 4
                button.addGestureRecognizer(holdGesture)
                numberOfRecords += 1
                
                self.view.subviews[0].addSubview(button)
            }
        }
        
        
        print("microphone was pressed");
    }
    
    
    @objc func buttonAction(sender: UIButton!) {
        
        do {
            print("Button tapped")
            
            audioPlayer = try AVAudioPlayer(contentsOf: paths[sender.tag])
            print(numberOfRecords)
            audioPlayer.volume = 40.0
            audioPlayer.prepareToPlay()
            audioPlayer.play()
        }
        catch {
            print(error)
        }
        
    }
    
    func fadeOut(duration: TimeInterval = 1.0, delay: TimeInterval = 0.0, completion: @escaping ((Bool) -> Void) = {(finished: Bool) -> Void in}) {
        UIView.animate(withDuration: duration, delay: delay, options: UIView.AnimationOptions.curveEaseIn, animations: {
            self.instructions.alpha = 0
        }, completion: completion)
    }
    
    func fadeIn(duration: TimeInterval = 1.0, delay: TimeInterval = 0.0, completion: @escaping ((Bool) -> Void) = {(finished: Bool) -> Void in}) {
        UIView.animate(withDuration: duration, delay: delay, options: UIView.AnimationOptions.curveEaseIn, animations: {
            self.instructions.alpha = 1
        }, completion: completion)
    }
    
    
    @IBOutlet weak var scrollView: ScrollView!
    var gesture = UIPinchGestureRecognizer()
    
    override func viewDidAppear(_ animated: Bool) {
        self.recordingSession = AVAudioSession.sharedInstance()
        
        do {
            try recordingSession.setCategory(AVAudioSession.Category.playAndRecord, mode: .measurement, options: .defaultToSpeaker)
        } catch {
            
        }
        do {
            try recordingSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if (self.instructions.alpha != 1) {
            self.instructions.alpha = 1;
        }
        gesture = UIPinchGestureRecognizer(target: self, action: #selector(pinchAction(sender:)))
        scrollView.addGestureRecognizer(gesture)
        
        scrollView.transform = CGAffineTransform(scaleX: 10, y: 10)
        scrollView.delaysContentTouches = false
        UIView.appearance().isExclusiveTouch = true
        //UIView.appearance().isMultipleTouchEnabled = false
        self.view.subviews[0].isMultipleTouchEnabled = false
        //let img = UIImage(named: "audioIcon.jpg")!.withAlignmentRectInsets(UIEdgeInsets.init(top: 50, left: 0, bottom: 0, right: 0))
        audioRecorder = nil

        recordingSession = AVAudioSession.sharedInstance()
        AVAudioSession.sharedInstance().requestRecordPermission{ (hasPermission) in
            if hasPermission
            {
                print("ACCEPTED")
                
            }
        }
        tableOTags.dataSource = self
        tableOTags.delegate = self
        addTextField.delegate = self
    }

    //var isZooming = false
    
    var imageViewScale: CGFloat = 1.0
    let maxScale: CGFloat = 4.0
    let minScale: CGFloat = 1.0
    
    @objc func holdAction(sender: UILongPressGestureRecognizer) {
        if sender.state == .began {
            //sender.view?.removeFromSuperview()
            if !held {
                held = true
                heldImage = sender.view as? UIImageView
                heldButton = sender.view as? UIButton
                var x = CGFloat(0)
                var y = CGFloat(0)
                let trashImg = #imageLiteral(resourceName: "Trash")
                if (heldImage != nil) {
                    
                    if (heldImage?.frame.width == ((heldImage?.image?.size.width)! / 10) ) {
                        print("drawing")
                        x = CGFloat((heldImage?.center.x)! + ((heldImage?.image?.size.width)! / 10) / 2)
                        y = CGFloat((heldImage?.center.y)! - ((heldImage?.image?.size.height)! / 10) / 2)
                        currTrash = UIButton(frame: CGRect(x: x, y: y, width: trashImg.size.width / 15, height: trashImg.size.height / 15))
                    } else {
                        x = CGFloat((heldImage?.center.x)! + ((heldImage?.image?.size.width)! / 300) / 2)
                        y = CGFloat((heldImage?.center.y)! - ((heldImage?.image?.size.height)! / 300) / 2)
                        currTrash = UIButton(frame: CGRect(x: x, y: y, width: trashImg.size.width / 30, height: trashImg.size.height / 30))
                    }
                } else if (heldButton != nil) {
                    //print(heldButton?.imageView?)
                    x = CGFloat((heldButton?.center.x)! + ((heldButton?.image(for: .normal)!.size.width)! / 50) / 2)
                    y = CGFloat((heldButton?.center.y)! - ((heldButton?.imageView?.image!.size.height)! / 50) / 2)
                    currTrash = UIButton(frame: CGRect(x: x, y: y, width: trashImg.size.width / 50, height: trashImg.size.height / 50))
                }
//                var x = CGFloat(0)
//                var y = CGFloat(0)
//                let trashImg = #imageLiteral(resourceName: "Trash")
//                if (heldImage?.frame.width == ((heldImage?.image?.size.width)! / 300)) {
//                    x = CGFloat((heldImage?.center.x)! + ((heldImage?.image?.size.width)! / 300) / 2)
//                    y = CGFloat((heldImage?.center.y)! - ((heldImage?.image?.size.height)! / 300) / 2)
//                    currTrash = UIButton(frame: CGRect(x: x, y: y, width: trashImg.size.width / 25, height: trashImg.size.height / 25))
//                } else {
//                    x = CGFloat((heldImage?.center.x)! + ((heldImage?.image?.size.width)! / 10) / 2)
//                    y = CGFloat((heldImage?.center.y)! - ((heldImage?.image?.size.height)! / 10) / 2)
//                    currTrash = UIButton(frame: CGRect(x: x, y: y, width: trashImg.size.width / 15, height: trashImg.size.height / 15))
//                }
//                let x = CGFloat((heldImage?.center.x)! + ((heldImage?.image?.size.width)! / 10) / 2)
//                let y = CGFloat((heldImage?.center.y)! - ((heldImage?.image?.size.height)! / 10) / 2)
                
                
//                currTrash = UIButton(frame: CGRect(x: x, y: y, width: trashImg.size.width / 15, height: trashImg.size.height / 15))
                currTrash?.setImage(trashImg, for: UIControl.State.normal)
                currTrash?.isUserInteractionEnabled = true
                currTrash?.addTarget(self, action: #selector(clickTrash), for: .touchUpInside)
                print("adding button")
                self.view.subviews[0].addSubview(currTrash!)
                //have button show up and link it
                //self.view.isUserInteractionEnabled = false
                self.view.subviews[3].isUserInteractionEnabled = false
                //only enable interaction on this element
                print("hold detected")
            }
            
        } else if sender.state == .ended {
            print("hold ended")
        }
    }
    
    @objc func clickTrash(sender: UIButton!) {
        let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Delete", style: .default, handler: { (action:UIAlertAction) in
            self.okToDelete()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(actionSheet, animated: true, completion: nil)
    
    }
    
    @objc func okToDelete() {
        heldImage?.removeFromSuperview()
        heldImage = nil
        currTrash?.removeFromSuperview()
        held = false
        currTrash = nil
        heldButton?.removeFromSuperview()
        self.view.subviews[3].isUserInteractionEnabled = true
    }
    
    @objc func pinchAction(sender:UIPinchGestureRecognizer) {
        if sender.state == .began || sender.state == .changed {
            guard let view = sender.view else {return}
            let pinchCenter = CGPoint(x: sender.location(in: view).x - view.bounds.midX,
                                      y: sender.location(in: view).y - view.bounds.midY)
            let transform = view.transform.translatedBy(x: pinchCenter.x, y: pinchCenter.y)
                .scaledBy(x: sender.scale, y: sender.scale)
                .translatedBy(x: -pinchCenter.x, y: -pinchCenter.y)
            let currentScale = scrollView.frame.size.width / scrollView.bounds.size.width
            var newScale = currentScale*sender.scale
            if newScale < 1 {
                newScale = 1
                let transform = CGAffineTransform(scaleX: newScale, y: newScale)
                scrollView.transform = transform
                sender.scale = 1
            } else {
                view.transform = transform
                sender.scale = 1
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }
        swiped = false
        lastPoint = touch.location(in: view)
    }

    func drawLine(from fromPoint: CGPoint, to toPoint: CGPoint) {
        // 1
        if !drawing {
            return
        }
        UIGraphicsBeginImageContext(view.frame.size)
        guard let context = UIGraphicsGetCurrentContext() else {
            return
        }
        tempDrawImage.image?.draw(in: view.bounds)
        
        // 2
        context.move(to: fromPoint)
        context.addLine(to: toPoint)
        
        // 3
        context.setLineCap(.round)
        context.setBlendMode(.normal)
        context.setLineWidth(brushWidth)
        context.setStrokeColor(color.cgColor)
        
        // 4
        context.strokePath()
        
        // 5
        tempDrawImage.image = UIGraphicsGetImageFromCurrentImageContext()
        tempDrawImage.alpha = opacity
        UIGraphicsEndImageContext()
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }
        
        // 6
        swiped = true
        let currentPoint = touch.location(in: view)
        drawLine(from: lastPoint, to: currentPoint)
        
        // 7
        lastPoint = currentPoint
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if !swiped {
            // draw a single point
            drawLine(from: lastPoint, to: lastPoint)
        }
        
        // Merge tempImageView into mainImageView
        UIGraphicsBeginImageContext(mainImage.frame.size)
        mainImage.image?.draw(in: view.bounds, blendMode: .normal, alpha: 1.0)
        tempDrawImage?.image?.draw(in: view.bounds, blendMode: .normal, alpha: opacity)
        mainImage.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        tempDrawImage.image = nil
    }
    
    
    @IBOutlet weak var containerView2: UIView!
    var videos: [String] = []
    @IBAction func finishTagging(_ sender: Any) {
        if (addTextField.text != "") {
            insertNewTag()
        }
        tagPage.isHidden = true
        if (!drawing) {
            scrollView.isUserInteractionEnabled = true
        }
        
        if (title == "HomeScreen") {
            containerView.isUserInteractionEnabled = true
        } else if (title == "HomeScreen2") {
            containerView2.isUserInteractionEnabled = true
        }
            
        //        add Kendall's saved. functionality but w this?
        //        does this work?
        taggingLabel.isHidden = false
        UIView.animate(withDuration: 5, animations: { () -> Void in
            self.taggingLabel.alpha = 0
            print("fading out save")
        }, completion: {(finished: Bool) in
            print("fading out save done")
            self.taggingLabel.isHidden = true
            self.taggingLabel.alpha = 1
        })
        
    }
    
    func insertNewTag() {
        videos.append(addTextField.text!)
        let indexPath = IndexPath(row: videos.count - 1, section: 0)
        tableOTags.beginUpdates()
        tableOTags.insertRows(at: [indexPath], with: .automatic)
        tableOTags.endUpdates()
        addTextField.text = ""
        view.endEditing(true)
    }
    
    
    @IBOutlet weak var addTextField: UITextField!
    
    @IBAction func keyToolbar(_ sender: Any) {
        tagSuggs = UIToolbar(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        
        // set the color of the toolbar
        tagSuggs.barStyle = .default
        tagSuggs.tintColor = UIColor.black
        tagSuggs.backgroundColor = UIColor.clear
        
        let flexButton = UIBarButtonItem(title: "Family", style: .plain, target: self, action: nil)
        let collectButton = UIBarButtonItem(title: "LA Trip", style: .plain, target: self, action: nil)
        let tagButton = UIBarButtonItem(title: "Vacation", style: .plain, target: self, action: nil)
        let space = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        
        // add the buttons on the toolbar
        tagSuggs.items = [flexButton, space, tagButton, space, collectButton]
        
        // add the toolbar to the view.
        addTextField.inputAccessoryView = tagSuggs
    }
    
    @IBOutlet weak var tagPage: UIView!
    
    @IBOutlet weak var tableOTags: UITableView!
    
    
    @IBOutlet weak var taggingLabel: UILabel!
    

    @IBOutlet weak var saveLabel: UILabel!
    @IBOutlet weak var saveLabel2: UILabel!
    
}
extension HomeScreen: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return videos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableOTags.dequeueReusableCell(withIdentifier: "TagCell", for: indexPath)
        let customCell = cell as? TagCell
        customCell?.tagLabel.text = videos[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            videos.remove(at: indexPath.row)
            
            tableOTags.beginUpdates()
            tableOTags.deleteRows(at: [indexPath], with: .automatic)
            tableOTags.endUpdates()
        }
    }
}
