//
//  TagCell.swift
//  Pensieve
//
//  Created by Stephen Dirk M. Weyns on 7/12/18.
//  Copyright © 2018 Pensieve. All rights reserved.
//

import UIKit

class TagCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var tagLabel: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
