//
//  CollectionsControllerTableViewController.swift
//  Pensieve
//
//  Created by Stephen Dirk M. Weyns on 4/12/18.
//  Copyright © 2018 Pensieve. All rights reserved.
//

import UIKit
let kReUseIdentifier: String = "main"

class CollectionsControllerTableViewController: UITableViewController, UISearchBarDelegate {
    
   // var recentlyDeleted = false
    func captureScreen() -> UIImage
    {
        
        //UIGraphicsBeginImageContext(view.frame.size)
        UIGraphicsBeginImageContextWithOptions(CGSize(width: view.frame.size.width, height: view.frame.size.height), false, 0)
        view.layer.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        //UIImageWriteToSavedPhotosAlbum(image!, nil, nil, nil)
        return image!
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.delegate = self
        tableView.dataSource = self
        tableView.delaysContentTouches = false
        tableView.separatorStyle = .none
        
        let button = UIButton(frame: CGRect(origin: CGPoint(x: self.view.frame.width - 70, y: self.view.frame.height - 70), size: CGSize(width: 50, height:50)))
        
        let img = UIImage(named: "plus button")
        //donebutton.isHidden = true
        button.setImage(img, for: .normal)
        //button.backgroundColor = UIColor.black
       button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        self.navigationController?.view.addSubview(button)
        self.navigationController?.isNavigationBarHidden = true
        searchbar.delegate = self
        
//        let tapGesture = UITapGestureRecognizer(target: self, action: Selector("Tap"))  //Tap function will call when user tap on button
//        let longGesture = UILongPressGestureRecognizer(target: self, action: Selector("Long")) //Long function will call when user long press on button.
//        tapGesture.numberOfTapsRequired = 1
//        btn.addGestureRecognizer(tapGesture)
//        btn.addGestureRecognizer(longGesture)
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchbar.resignFirstResponder()
    }
    
    override func viewWillAppear(_ animated: Bool) {
//        if Singleton.sharedInstance.numMemories == 2 {
//
//        }
    }
    
    @IBAction func unwindToCollections(segue:UIStoryboardSegue) { }
    

    @IBOutlet weak var searchbar: UISearchBar!
    @objc func buttonAction1(sender: UIButton!) {
        performSegue(withIdentifier:
            "unwindSegueToVC1", sender: self)
        print("unwind to VC1")
    }
    
    @objc func buttonAction(sender: UIButton!) {
        
        //plusbutton needs to perform segue
        performSegue(withIdentifier: "toMemory2", sender: self)
        Singleton.sharedInstance.numMemories += 1
        Singleton.sharedInstance.currentMemory += 1
        //Singleton.sharedInstance.numTags += 1
        
        print ("plus button clicked")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func backToMemory2(_ sender: Any) {
        print("going back to memory2");
        performSegue(withIdentifier: "unwindSegueToVC2", sender: self)
        Singleton.sharedInstance.currentMemory = 1
    }
    // MARK: - Table view data source
    @IBAction func backToMemory(_ sender: Any) {
        print("going back to memory 1")
        performSegue(withIdentifier: "unwindSegueToVC1", sender: self)
        Singleton.sharedInstance.currentMemory = 0
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        //number of cells you want
        return Singleton.sharedInstance.numTags()
    }
    func UIColorFromRGB(rgbValue: UInt, alpha: CGFloat) -> UIColor {
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: alpha
        )
    }

    var customCell1 : CollectionCellTableViewCell? = nil
    
    @objc func Long(sender: UILongPressGestureRecognizer) {
        print("hi")
        customCell1?.collTag.isHidden = false
        customCell1?.collTrash.isHidden = false
        //collTrash.isHidden = false
        //collTag.isHidden = false
        
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: kReUseIdentifier, for: indexPath)
        cell.selectionStyle = UITableViewCell.SelectionStyle.none
        if (indexPath.row % 2 == 0) {
            cell.backgroundColor = UIColorFromRGB(rgbValue: 0xF7E1C6, alpha: 0.2)
        } else {
            cell.backgroundColor = UIColorFromRGB(rgbValue: 0xFFFFF0, alpha: 1)
        }
        let customCell = cell as? CollectionCellTableViewCell
        customCell?.button1.layer.cornerRadius = 10
        customCell?.button1.clipsToBounds = true
        customCell?.button1.layer.borderWidth = 2
        customCell?.button1.layer.borderColor = UIColorFromRGB(rgbValue: 0x877362, alpha: 1).cgColor
        //877362
        customCell?.button2.layer.cornerRadius = 10
        customCell?.button2.clipsToBounds = true
        customCell?.button2.layer.borderWidth = 2
        customCell?.button2.layer.borderColor = UIColorFromRGB(rgbValue: 0x877362, alpha: 1).cgColor
//        if (Singleton.sharedInstance.numMemories >= 2 && indexPath.row < 2) {
        if (indexPath.row < 2) {
            customCell?.button2.setImage(Singleton.sharedInstance.images[1], for: .normal)
            
            customCell?.button1.setImage(Singleton.sharedInstance.images[0], for: .normal)
        }
        
        
//        print(Singleton.sharedInstance.numMemories)
//        print(Singleton.sharedInstance.currentMemory)
        if indexPath.row == 0 {
            if (Singleton.sharedInstance.recentlyDeleted) {
                customCell?.button3.isHidden = true
            }
            customCell?.tagLabel.text = "Recent"
            customCell1 = customCell
            //customCell?.button1.setImage(captureScreen(), for: .normal)
            //button.setImage(img, for: .normal)
            
            let longGesture = UILongPressGestureRecognizer(target: self, action: #selector(Long(sender:)))
            longGesture.minimumPressDuration = 1.0 // 1 second press
            longGesture.allowableMovement = 10
            //let longGesture = UILongPressGestureRecognizer(target: self, action: Long()) //Long function will call when user long press on button.
        customCell?.button3.addGestureRecognizer(longGesture)
            
            
            
            
            //this takes care of adding button 2
            if (Singleton.sharedInstance.numMemories == 1) {
                customCell?.button2.isHidden = true
            }
            if (Singleton.sharedInstance.numMemories == 2) {
                customCell?.button2.isHidden = false
            }
        }
        if indexPath.row == 1 {
            customCell?.tagLabel.text = "Untagged"
            
            //this takes care of "adding button 2
            if (Singleton.sharedInstance.numMemories == 1) {
                customCell?.button2.isHidden = true
            }
            if (Singleton.sharedInstance.numMemories == 2) {
                customCell?.button2.isHidden = false
            }
        }
        if indexPath.row == 2 {
            customCell?.button1.isHidden = true
            customCell?.button2.isHidden = true
            customCell?.tagLabel.text = "Recently Deleted"
        }
        if (indexPath.row > 0) {
            //if its visible then do it
            customCell?.button3.isHidden = true
        }
        if (indexPath.row == 2) {
            if (Singleton.sharedInstance.recentlyDeleted) {
                customCell?.button3.isHidden = false
                customCell?.button3.center = (customCell?.button1.center)!
            }
        }
        if (indexPath.row > 2) {
            customCell?.button1.isHidden = true
            customCell?.button2.isHidden = true
            
            if ((indexPath.row - 3) < Singleton.sharedInstance.tags1.count) {
                customCell?.tagLabel.text = Singleton.sharedInstance.tags1[indexPath.row - 3]
                let correctPosition = CGPoint(x: (customCell?.button1.center.x)! - 96 / 2, y: (customCell?.button1.center.y)! - 96 / 2)
                let button = UIButton(frame: CGRect(origin: correctPosition, size: CGSize(width: 96, height:96)))
                
                //let img = UIImage(named: "plus button")
                //donebutton.isHidden = true
                button.setImage(Singleton.sharedInstance.images[0], for: .normal)
                //button.backgroundColor = UIColor.black
                button.addTarget(self, action: #selector(button1Action), for: .touchUpInside)
                button.isUserInteractionEnabled = true
                button.layer.cornerRadius = 10
                button.clipsToBounds = true
                button.layer.borderWidth = 2
                button.layer.borderColor = UIColorFromRGB(rgbValue: 0x877362, alpha: 1).cgColor
                //print("button added ")
                customCell?.contentView.addSubview(button)
            } else if ((indexPath.row - 3) < (Singleton.sharedInstance.tags1.count + Singleton.sharedInstance.tags2.count)) {
                customCell?.tagLabel.text = Singleton.sharedInstance.tags2[indexPath.row - 3 - Singleton.sharedInstance.tags1.count]
                //customCell?.tagLabel.text = Singleton.sharedInstance.tags1[indexPath.row - 2]
                let correctPosition = CGPoint(x: (customCell?.button1.center.x)! - 96 / 2, y: (customCell?.button1.center.y)! - 96 / 2)
                let button = UIButton(frame: CGRect(origin: correctPosition, size: CGSize(width: 96, height:96)))
                
                //let img = UIImage(named: "plus button")
                //donebutton.isHidden = true
                button.setImage(Singleton.sharedInstance.images[1], for: .normal)
                //button.backgroundColor = UIColor.black
                button.addTarget(self, action: #selector(button2Action), for: .touchUpInside)
                //button.isUserInteractionEnabled = true button.isUserInteractionEnabled = true
                button.layer.cornerRadius = 10
                button.clipsToBounds = true
                button.layer.borderWidth = 2
                button.layer.borderColor = UIColorFromRGB(rgbValue: 0x877362, alpha: 1).cgColor
                customCell?.contentView.addSubview(button)
                //add a button for remove it from the
                
            }
        }
        
        //if (indexPath.row)
        
        
        
        
        //set up the cell here 
        

        return cell
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 150;//Choose your custom row height
    }
    
    @objc func button1Action(sender: UIButton!) {
        print("going back to memory 1")
        performSegue(withIdentifier: "unwindSegueToVC1", sender: self)
        Singleton.sharedInstance.currentMemory = 0
        
    }
    
    @objc func button2Action(sender: UIButton!) {
        print("going back to memory2");
        performSegue(withIdentifier: "unwindSegueToVC2", sender: self)
        Singleton.sharedInstance.currentMemory = 1
    }
    

    @IBAction func Delete(_ sender: Any) {
//        let refreshAlert = UIAlertController(title: "Refresh", message: "All data will be lost.", preferredStyle: UIAlertController.Style.alert)
//
//        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
//            print("Handle Ok logic here")
//        }))
//
//        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
//            print("Handle Cancel Logic here")
//        }))
//
//        present(refreshAlert, animated: true, completion: nil)
        
        let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Delete", style: .default, handler: { (action:UIAlertAction) in
            print("second")
           self.customCell1!.button3.isHidden = true
            self.customCell1!.collTrash.isHidden = true
            self.customCell1!.collTag.isHidden = true
            Singleton.sharedInstance.recentlyDeleted = true
            self.tableView.reloadData()
        }))
        
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(actionSheet, animated: true, completion: nil)
        
        
        
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
