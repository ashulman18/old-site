//
//  CollectionCellTableViewCell.swift
//  Pensieve
//
//  Created by Stephen Dirk M. Weyns on 4/12/18.
//  Copyright © 2018 Pensieve. All rights reserved.
//

import UIKit

class CollectionCellTableViewCell: UITableViewCell {


    @IBOutlet weak var tagLabel: UILabel!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button1: UIButton!
    
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var collTrash: UIButton!
    
    @IBOutlet weak var collTag: UIButton!
    
    
//    @objc func Long(sender: UILongPressGestureRecognizer) {
//        print("hi")
//
//        collTrash.isHidden = false
//        collTag.isHidden = false
//
//    }
    
}
