//
//  ViewController.swift
//  Pensieve
//
//  Created by Stephen Dirk M. Weyns on 22/11/18.
//  Copyright © 2018 Pensieve. All rights reserved.
//

import UIKit

class TitleScreen: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

