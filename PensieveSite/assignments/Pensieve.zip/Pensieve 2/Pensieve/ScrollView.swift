//
//  ScrollView.swift
//  Pensieve
//
//  Created by Stephen Dirk M. Weyns on 24/11/18.
//  Copyright © 2018 Pensieve. All rights reserved.
//

import UIKit

class ScrollView: UIScrollView {
    
    var currentImageView : UIImageView? = nil
    var currentScrollView : UIScrollView? = nil
    var currentTextField : UITextField? = nil
    
    var location = CGPoint(x: 0, y: 0)
    var superLocation = CGPoint(x: 0, y: 0)
    var offset = CGPoint(x: 0, y: 0)
    var xOffset = CGFloat(0)
    var yOffset = CGFloat(0)
    var homeScreen : HomeScreen? = nil
    
    override func awakeFromNib() {
        homeScreen = viewController(forView: self) as? HomeScreen
    }
    
    func viewController(forView: UIView) -> UIViewController? {
        var nr = forView.next
        while nr != nil && !(nr! is UIViewController) {
            nr = nr!.next
        }
        return nr as? UIViewController
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch : UITouch! =  touches.first! as UITouch
        if homeScreen?.held == true {
            return
        }
        location = touch.location(in: self)
        superLocation = touch.location(in: self.superview)
        //print("There is a textfield")
        if currentImageView == nil {
            //print("There is an image")
            if let touchedImageView = self.hitTest(location, with: nil) as? UIImageView {
                currentImageView = touchedImageView
                self.bringSubviewToFront(currentImageView!)
                xOffset = (currentImageView?.center.x)! - location.x
                yOffset = (currentImageView?.center.y)! - location.y
            } else {
                currentImageView = nil
            }
        }
        
        if currentScrollView == nil {
            //print("There is a scrollview")
            if let touchedScrollView = self.superview?.hitTest(superLocation, with: nil) as? UIScrollView {
                currentScrollView = touchedScrollView
                //print("new scrollview")
                xOffset = (currentScrollView?.center.x)! - superLocation.x
                yOffset = (currentScrollView?.center.y)! - superLocation.y
                //print (xOffset)
                //print (yOffset)
            } else {
                currentScrollView = nil
            }
        }
        
        if currentTextField == nil {
            
            if let touchedTextField = self.hitTest(location, with: nil) as? UITextField {
                currentTextField = touchedTextField
                self.bringSubviewToFront(currentTextField!)
                xOffset = (currentTextField?.center.x)! - location.x
                yOffset = (currentTextField?.center.y)! - location.y
                
            } else {
                currentTextField = nil
            }
        }
        
        
//        let newPoint = CGPoint(x: location.x + xOffset, y: location.y + yOffset)
//        currentImageView?.center = newPoint
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch : UITouch! =  touches.first! as UITouch
        if homeScreen?.held == true {
            return
        }
        
        location = touch.location(in: self)
        superLocation = touch.location(in: self.superview)
        let newPoint = CGPoint(x: location.x + xOffset, y: location.y + yOffset)
        
        
        
        
        if (currentScrollView != nil) {
            let newPoint1 = CGPoint(x: superLocation.x + xOffset, y: superLocation.y + yOffset)
            currentScrollView?.center = newPoint1
        }
        
        currentTextField?.center = newPoint
        
        currentImageView?.center = newPoint
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        if homeScreen?.held == true {
            return
        }
        currentImageView = nil
        currentScrollView = nil
        currentTextField = nil
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if homeScreen?.held == true {
            return
        }
        currentScrollView = nil
        currentImageView = nil
        currentTextField = nil
    }
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
