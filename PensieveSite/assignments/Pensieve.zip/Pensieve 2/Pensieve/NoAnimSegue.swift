//
//  NoAnimSegue.swift
//  Pensieve
//
//  Created by Tina Jiang on 12/6/18.
//  Copyright © 2018 Pensieve. All rights reserved.
//

import UIKit

class NoAnimSegue: UIStoryboardSegue {
    override func perform() {
        self.source.navigationController?.pushViewController(self.destination, animated: false)
    }
}
