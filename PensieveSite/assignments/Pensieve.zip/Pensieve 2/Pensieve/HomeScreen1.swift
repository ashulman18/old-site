import UIKit

class HomeScreen1: HomeScreen {
    @IBAction func unwindToVC2(segue: UIStoryboardSegue) {
        print("unwound2")
    }
}
